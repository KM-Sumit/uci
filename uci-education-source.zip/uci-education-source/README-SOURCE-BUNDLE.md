# UCI Government Exam Preparation — source bundle

This archive contains the Expo student app, the Express API, the Drizzle database schema, and the shared/generated API contracts used by this app. It excludes installed dependencies, build output, caches, Replit secrets, and environment files.

## Workspace contents

- `artifacts/uci-education` — Expo app screens and client-side state
- `artifacts/api-server` — API routes, authentication, and seed scripts
- `lib/db` — database connection and schema
- `lib/api-spec`, `lib/api-zod`, `lib/api-client-react` — API definition and generated clients
- Root pnpm workspace configuration and lockfile

## Runtime configuration

No credentials are included. The API requires `DATABASE_URL` and `SESSION_SECRET` in the environment. Apply the schema with `pnpm --filter @workspace/db run push`, then seed starter content with `pnpm --filter @workspace/api-server run seed:content`.

Start the API with `pnpm --filter @workspace/api-server run dev`. Start the Expo app in the Replit environment with its existing `dev` script; `EXPO_PUBLIC_DOMAIN` must point to the API host without an `https://` prefix.

To enable an administrator account, set `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_MOBILE`, and `ADMIN_PASSWORD` as environment secrets, then run `pnpm --filter @workspace/api-server run seed:admin`. Student sign-up never creates administrator accounts.

This is source code, not a compiled Android or iOS installer. Install dependencies with pnpm in a compatible workspace and configure a PostgreSQL database before running the full app.
